

class NewsController {
    // GET /news
    index(req, res) {
        res.render('news')
    }
    // GET /search
    show(req, res) {
        res.render('NEW DETAIl!!!');
    }
}
module.exports = new NewsController;
