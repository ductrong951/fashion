
const course = require("../models/course");
const { mutipleMongooseToOject } = require('../../until/mongoose');

class SiteController {
    // GET /news
    index(req, res, next) {

        // course.find({}, function (err, courses) {
        //     if (!err) {
        //     res.json (courses);
        // }
        // else {
        //     res.status(400).json({ error: 'error!!'})}
        // }); 

        course.find({})
            .then(courses => {
                // courses = courses.map(courses => courses.toObject())
                res.render ('home', { 
                    courses: mutipleMongooseToOject(courses)
                })
            })
            .catch(next);

        // res.render('home')
    }
    // GET /search
    search(req, res) {
        res.render('search');
    }
}
module.exports = new SiteController;
