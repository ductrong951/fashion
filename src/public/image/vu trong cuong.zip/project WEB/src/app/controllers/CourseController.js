
const course = require("../models/course");
const { mutipleMongooseToOject } = require('../../until/mongoose');

class CourseController {
    // GET 
    show(req, res) {
        res.send('COURSE DETAIL!!!');
    }
}
module.exports = new CourseController();
