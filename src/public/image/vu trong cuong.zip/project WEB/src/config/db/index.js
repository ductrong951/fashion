const mongoose = require('mongoose');

async function connect() {

        try{
            await mongoose.connect('mongodb://localhost:27017/F8_education_dev ', {
                useNewURLParser: true,
                useUnifiedTopology: true
            });
            console.log('connect susessfuly!!!')
        } catch (error){
            console.log('connect faillure !!!')
        };
}

module.exports = { connect };