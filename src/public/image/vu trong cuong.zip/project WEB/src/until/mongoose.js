module.exports = {
    mutipleMongooseToOject: function(mongooses) {
        return mongooses.map(mongooses => mongooses.toObject())
    },
    mongooseToObject: function (mongooses){
        return mongoose ? mongooseToObject() : mongoose;
    }
};