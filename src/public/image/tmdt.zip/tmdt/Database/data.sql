Create table sanpham(
    MaSp int NOT NULL AUTO_INCREMENT PRIMARY Key,
    TenSp varchar(255) not null,
    Loai varchar(255) not null,
    Price int not null,
    Descrition  varchar(4000) not null,
    path_img varchar(255)
);


