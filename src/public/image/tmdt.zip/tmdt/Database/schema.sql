Create database TMDT 

Create table SanPham(

    MaSp int NOT NULL AUTO_INCREMENT
    TenSp nvarchar(255) not null;
    Loai nvarchar(255) not null;
    Descrition nvarchar(255) not null;
);

Create table Loai(
    MaLoai int not Null AUTO_INCREMENT;
    TenLoai nvarchar(255) not null;
)