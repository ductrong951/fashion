const db = require('../config/database');


const SanPham = function(SanPham){
    this.MaSp = MaSp
    this.TenSp = TenSp;
    this.Loai = Loai;
    this.Price = Price
    this.path_img = path_img
    this.Descrition = Descrition
   
}


SanPham.getAll = (result) => {

    db.query("SELECT * FROM SanPham",function(err,SanPham){
        if(err || SanPham.length ==0) result(null);
        else result(SanPham);
        
    });
};


SanPham.create = (SanPham, result) => {
    db.query("INSERT INTO SanPham SET ? ",SanPham, function(err, res) {
        if (err) {
            console.log("error: ", err);
            result(err, null);
            return;
        }
        
        result('thanhcong');
        console.log('thanhcong')
    });
};

SanPham.findbyoneid = function(MaSp,result){
    db.query('SELECT * FROM SanPham WHERE MaSp = ? ',MaSp,function(err,SanPham){
        if(err){ result(null);
        }
        else result(SanPham);
       
    });
}
SanPham.delete = function(id,result){
    db.query("DELETE FROM SanPham WHERE MaSp = ?",id,function(err,res){
        if(err) result(null);
        else result("thanhcong")
    });
}
SanPham.update = function(id,tensp,loai,mota,gia,result){
    
    db.query("Update  SanPham SET TenSp = ?, Loai = ? , Descrition = ?,Price = ? WHERE MaSp = ?",[tensp,loai,mota,gia,id],function(err,res){
        if(err){
            result(null)
            console.log(err)
        } 
        else result("thanhcong")
    });
}

module.exports = SanPham