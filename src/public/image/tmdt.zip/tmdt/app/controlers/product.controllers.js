const SanPham = require("../models/product.model");



exports.get_all = (req, res) => {
    SanPham.getAll(function(data){
        res.render('home',{userList:data})
    })
};

exports.get_one_by_id = (req, res) => {
    var MaSp=2
    SanPham.findbyoneid(MaSp, function(data) {
        
        
        res.send(data)
    });
};



exports.goTocreate =(req, res) => {

    SanPham.getAll(function(data){
        res.render('create')
    })
    
};

exports.goTohome =(req, res) => {

    
    SanPham.getAll(function(data){
        res.render('home',{userList:data})
    })
    
    
};

exports.gotoProduct =(req,res) =>{
    SanPham.getAll(function(data){
        res.render('product',{userList:data})
    })
}

exports.store = (req, res) => {
    // Validate request
    
    
    
   var sp = {
     TenSp : req.body.TenSp,
     Loai : req.body.Loai,
     Descrition : req.body.Descrition,
     Price:req.body.Price,
     path_img:"2"
   }
    
   

    
    // Save Todo in the database
    SanPham.create(sp, (err, data) => {
        
        console.log(sp)
        res.redirect('/product')
    });
};


exports.GotoEditPage = (req,res) =>
{  
    let MaSp = req.params.MaSp
    SanPham.findbyoneid(MaSp, function(data) {
        
        
        res.render('update',{userList:data[0]})
        // console.log(data[0])
    });
}

exports.remove_product = (req,res) =>
{  
    var Masp = req.body.ProductID
    
    SanPham.delete(Masp, function(data) {
        
        
       
        res.redirect("/product?delete=success")
        
    });
   
}
exports.edit_product = (req,res) =>
{ 
    var Masp = req.body.ProductID
    var TenSp = req.body.TenSp
    var Loai = req.body.Loai
    var Descrition = req.body.Descrition
    var price = Number(req.body.Price)
    console.log(price)
    SanPham.update(Masp,TenSp,Loai, Descrition,price, function(data) {
        
        
       
        res.redirect("/product")
        console.log("thanhcong")
    });
   
}