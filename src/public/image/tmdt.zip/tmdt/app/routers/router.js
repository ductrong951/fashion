var ProductControllers = require("../controlers/product.controllers")

// const moment = require('moment');
var express = require('express');


var router = express.Router();
router.get('/',ProductControllers.get_all);
router.post ('/create',ProductControllers.store)


router.get("/create",ProductControllers.goTocreate)

router.get("/home",ProductControllers.goTohome)
router.get("/product",ProductControllers.gotoProduct)

router.get('/product',ProductControllers.get_one_by_id)
router.get('/edit-product/:MaSp',ProductControllers.GotoEditPage)
router.post('/edit-product',ProductControllers.edit_product)
router.post('/delete-product',ProductControllers.remove_product)
module.exports = router;