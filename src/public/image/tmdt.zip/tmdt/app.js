const express = require("express");
const app = express();
const bodyParser = require('body-parser');
const methodOverride = require('method-override');
const session = require('express-session');


app.use(bodyParser.urlencoded({ extended: true }));
app.set('view engine', 'ejs')
app.set('views', 'app/views');

app.use(express.static(__dirname + '/public'));


app.get( (req, res, next) => {
    res.render('index');
})

app.use(require('./app/routers/router'))

app.listen(3000, function() {
    console.log('server running: http://localhost:3000');
});

